document.addEventListener('DOMContentLoaded', function() {
    // Form validation and enhancement
    const convertForm = document.getElementById('convertForm');
    const urlInput = document.getElementById('url');
    const convertBtn = document.getElementById('convertBtn');
    
    if (convertForm && urlInput && convertBtn) {
        // YouTube URL validation patterns
        const youtubePatterns = [
            /^https?:\/\/(www\.)?youtube\.com\/watch\?v=[\w-]+/,
            /^https?:\/\/(www\.)?youtu\.be\/[\w-]+/,
            /^https?:\/\/(www\.)?youtube\.com\/embed\/[\w-]+/,
            /^https?:\/\/(www\.)?youtube\.com\/v\/[\w-]+/
        ];
        
        // Real-time URL validation
        urlInput.addEventListener('input', function() {
            const url = this.value.trim();
            const isValid = youtubePatterns.some(pattern => pattern.test(url));
            
            if (url && !isValid) {
                this.classList.add('is-invalid');
                this.classList.remove('is-valid');
            } else if (url && isValid) {
                this.classList.add('is-valid');
                this.classList.remove('is-invalid');
            } else {
                this.classList.remove('is-valid', 'is-invalid');
            }
        });
        
        // Form submission handling
        convertForm.addEventListener('submit', function(e) {
            const url = urlInput.value.trim();
            
            if (!url) {
                e.preventDefault();
                showAlert('Por favor, insira uma URL do YouTube.', 'danger');
                urlInput.focus();
                return;
            }
            
            const isValid = youtubePatterns.some(pattern => pattern.test(url));
            if (!isValid) {
                e.preventDefault();
                showAlert('URL inválida. Por favor, insira uma URL válida do YouTube.', 'danger');
                urlInput.focus();
                return;
            }
            
            // Show loading state
            convertBtn.innerHTML = `
                <div class="spinner-border spinner-border-sm me-2" role="status">
                    <span class="visually-hidden">Carregando...</span>
                </div>
                Convertendo...
            `;
            convertBtn.disabled = true;
        });
        
        // Paste handler for URL input
        urlInput.addEventListener('paste', function(e) {
            setTimeout(() => {
                this.dispatchEvent(new Event('input'));
            }, 10);
        });
    }
    
    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
    
    // Utility function to show alerts
    function showAlert(message, type = 'info') {
        const alertContainer = document.createElement('div');
        alertContainer.innerHTML = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                <i class="fas fa-${getAlertIcon(type)} me-2"></i>
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        const mainContainer = document.querySelector('main .container');
        if (mainContainer) {
            mainContainer.insertBefore(alertContainer.firstElementChild, mainContainer.firstElementChild);
        }
    }
    
    // Get appropriate icon for alert type
    function getAlertIcon(type) {
        switch(type) {
            case 'danger':
                return 'exclamation-triangle';
            case 'success':
                return 'check-circle';
            case 'warning':
                return 'exclamation-circle';
            default:
                return 'info-circle';
        }
    }
    
    // Add smooth scrolling for any anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add loading animation to any buttons with loading class
    document.querySelectorAll('.btn-loading').forEach(btn => {
        btn.addEventListener('click', function() {
            if (!this.disabled) {
                const originalText = this.innerHTML;
                this.innerHTML = `
                    <div class="spinner-border spinner-border-sm me-2" role="status">
                        <span class="visually-hidden">Carregando...</span>
                    </div>
                    Processando...
                `;
                this.disabled = true;
                
                // Re-enable after 30 seconds as fallback
                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.disabled = false;
                }, 30000);
            }
        });
    });
    
    // Add hover effects to feature icons
    document.querySelectorAll('.feature-icon').forEach(icon => {
        icon.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.1) rotate(5deg)';
        });
        
        icon.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1) rotate(0deg)';
        });
    });
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + Enter to submit form
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            const form = document.getElementById('convertForm');
            if (form && !convertBtn.disabled) {
                form.submit();
            }
        }
        
        // Escape key to clear form
        if (e.key === 'Escape' && urlInput) {
            urlInput.value = '';
            urlInput.classList.remove('is-valid', 'is-invalid');
            urlInput.focus();
        }
    });
});
